export const environment = {
  production: true,
  firebaseConfig: {
    apiKey: 'AIzaSyB6k2Bn2AXZNc0DGJ8H9blJTzGjRQbGxJI',
    authDomain: 'vvs-s-manager.firebaseapp.com',
    projectId: 'vvs-s-manager',
    storageBucket: 'vvs-s-manager.appspot.com',
    messagingSenderId: '298206622192',
    appId: '1:298206622192:web:b293f6d7b14f1831356d35'
  },
  googleClientid: '298206622192-ke686j1gaesu2t9fj72oad9tfep3esb9.apps.googleusercontent.com',
  baseUrl: 'http://localhost:3000/',
  supabaseUrl: 'https://wqyboimmwmmttlwyqmod.supabase.co',
  // eslint-disable-next-line max-len
  supabaseKey: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6IndxeWJvaW1td21tdHRsd3lxbW9kIiwicm9sZSI6ImFub24iLCJpYXQiOjE2NTYyNTQ3MjIsImV4cCI6MTk3MTgzMDcyMn0.YIL830W2oZUoTG_mm2t4Lzupm61jvqUFJer32vGjGIw'
};
