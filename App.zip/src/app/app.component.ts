import { DOCUMENT } from '@angular/common';
import { Component, Inject } from '@angular/core';
import { Router } from '@angular/router';
import { SplashScreen } from '@capacitor/splash-screen';
import { MenuController } from '@ionic/angular';
import { TranslateService } from '@ngx-translate/core';
import { from, of, switchMap } from 'rxjs';
import { JwtService } from './screens/shared/services/auth/jwt.service';
import { ConfigService } from './screens/shared/services/config.service';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(
    @Inject(DOCUMENT) private document: Document,
    private jwtService: JwtService,
    private user: UserService,
    private router: Router,
    private menu: MenuController,
    private config: ConfigService,
    private translate: TranslateService) {
    //  this.router.navigate(['/home'], { replaceUrl: true });
    // translate.addLangs(['en', 'ar']);
    translate.setDefaultLang('en');
    this.languageChanged();




    // this.user.getUser().then(async (u) => {
    //   console.log(u);
    //   if (u) {
    //     await this.router.navigate(['/home/listing'], { replaceUrl: true });
    //     SplashScreen.hide();
    //   }
    //   else {
    //     await this.router.navigate(['/getting-start'], { replaceUrl: true });
    //     SplashScreen.hide();
    //   }
    // })
    //   .catch(async (err) => {
    //     await this.router.navigate(['/getting-start'], { replaceUrl: true });
    //     SplashScreen.hide();
    //   });
  }

  switchLang(lang: string) {
    this.translate.use(lang);
  }

  languageChanged() {
    // localStorage.setItem('LANG', this.lang);
    // this.translate.setDefaultLang(this.lang);
    // if (this.lang === 'iw')
    
    this.document.documentElement.dir = 'rtl';
    // else
    // this.document.documentElement.dir = 'ltr';
  }

  ionViewDidEnter() {
    this.translate.use('ar');
    from(this.jwtService.getToken())
      .pipe(
        switchMap(token => {
          if (token) {
            this.router.navigate(['/home/listing'], { replaceUrl: true });
            this.menu.enable(true, 'main');
            SplashScreen.hide();
          }

          else {
            this.router.navigate(['/getting-start'], { replaceUrl: true });
            this.menu.enable(false, 'main');
            SplashScreen.hide();
          }
          return of();
        })
      );

  }
}
