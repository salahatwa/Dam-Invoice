export interface Food {
    id: number;
    title: string;
    price: number;
    image: string;
    description: string;
}