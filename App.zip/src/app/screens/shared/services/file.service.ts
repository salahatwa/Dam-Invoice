import { Injectable } from '@angular/core';
import { Platform } from '@ionic/angular';

import { FileOpener } from '@awesome-cordova-plugins/file-opener/ngx';
import { File } from '@awesome-cordova-plugins/file/ngx';
import { ToastService, ToastType } from './toast.service';

@Injectable({
  providedIn: 'root',
})
export class FileService {

  isLoading = false;
  loader: HTMLIonLoadingElement;
  constructor(
    private platform: Platform, private fileOpener: FileOpener, private file: File, private toastService: ToastService
  ) { }

  openBlobFile(data: any, type: string, filename: string) {
    let blob = new Blob([data], { type: type });


    const writeDirectory = this.platform.is('ios') ? this.file.dataDirectory : this.file.externalDataDirectory;
    console.log(writeDirectory);
    this.file.writeFile(writeDirectory, filename, blob, { replace: true })
      .then(() => {
        this.fileOpener.open(writeDirectory + filename, type)
          .catch(() => {
            console.log('Error opening pdf file');
          });
      })
      .catch(() => {
        console.error('Error writing pdf file');
        this.toastService.showToast('Error writing pdf file', ToastType.DANGER);
      });
  }
}
