import { NgModule } from '@angular/core';


import { CartPageRoutingModule } from './cart-routing.module';

import { CartItemModule } from '../../component/cart-item/cart-item.module';
import { SharedModule } from '../../shared/component/shared.module';
import { CartPage } from './cart.page';

@NgModule({
  imports: [
    SharedModule,
    CartPageRoutingModule,
    CartItemModule,
  ],
  declarations: [CartPage]
})
export class CartPageModule { }
