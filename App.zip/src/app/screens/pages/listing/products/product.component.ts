import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Food } from 'src/app/screens/models/food.model';
import { FoodService } from 'src/app/screens/services/food.service';

@Component({
  selector: 'app-product',
  templateUrl: './product.component.html',
  styleUrls: ['./product.component.scss'],
})
export class ProductComponent implements OnInit {
  foods: Food[] = [];

  constructor(private foodService: FoodService, private router: Router) { }

  ngOnInit() {
    this.foods = this.foodService.getFoods();
  }

  goToDetailPage(id: number) {
    console.log(id);
    this.router.navigate(['detail', id]);
  }

}
