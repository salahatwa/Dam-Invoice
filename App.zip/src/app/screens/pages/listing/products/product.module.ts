import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { FoodCardModule } from 'src/app/screens/component/food-card/food-card.module';
import { ProductComponent } from './product.component';


const routes: Routes = [
  {
    path: '',
    component: ProductComponent,
    outlet:'dashboard'
  }
]


@NgModule({
  declarations: [ProductComponent],
  imports: [
    CommonModule, IonicModule, FoodCardModule,
    RouterModule.forChild(routes),
  ],
  exports: [
    ProductComponent
  ]
})
export class ProductModule { }
