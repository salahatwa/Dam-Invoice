import { Component, OnInit } from '@angular/core';
import { Observable } from 'rxjs';
import { Food } from 'src/app/screens/models/food.model';
import { FoodService } from 'src/app/screens/services/food.service';


// Typescript custom enum for search types (optional)
export enum SearchType {
  all = '',
  movie = 'movie',
  series = 'series',
  episode = 'episode'
}


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss'],
})
export class CustomerComponent implements OnInit {



  results: Food[] = [];
  searchTerm: string = '';
  type: SearchType = SearchType.all;

  /**
   * Constructor of our first page
   * @param movieService The movie Service to get data
   */
  constructor(private foodService: FoodService) { }

  ngOnInit() {
    this.searchChanged();
  }

  searchChanged() {
    // Call our service function which returns an Observable
    this.results = this.foodService.getFoods();
  }
}
