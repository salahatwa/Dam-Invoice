import { Component, OnInit } from '@angular/core';
import { ModalController } from '@ionic/angular';
import { Observable } from 'rxjs';
import { Food } from 'src/app/screens/models/food.model';
import { FoodService } from 'src/app/screens/services/food.service';
import { CustomerFilterDialogComponent } from './customer-filter-dialog/customer-filter-dialog.component';


// Typescript custom enum for search types (optional)
export enum SearchType {
  all = '',
  movie = 'movie',
  series = 'series',
  episode = 'episode'
}


@Component({
  selector: 'app-customer',
  templateUrl: './customer.component.html',
  styleUrls: ['./customer.component.scss'],
})
export class CustomerComponent implements OnInit {



  results: Food[] = [];
  searchTerm: string = '';
  type: SearchType = SearchType.all;

  /**
   * Constructor of our first page
   * @param movieService The movie Service to get data
   */
  constructor(private foodService: FoodService,private modalCtrl: ModalController) { }

  ngOnInit() {
    this.searchChanged();
  }

  searchChanged() {
    // Call our service function which returns an Observable
    this.results = this.foodService.getFoods();
  }

  async openModal() {
    const modal = await this.modalCtrl.create({
      component: CustomerFilterDialogComponent,
    });
    modal.present();

    const { data, role } = await modal.onWillDismiss();

    if (role === 'confirm') {
      console.log( `Hello, ${data}!` );
    }
  }
}
