import { CommonModule } from '@angular/common';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms';
import { RouterModule, Routes } from '@angular/router';
import { IonicModule } from '@ionic/angular';
import { CustomerFilterDialogModule } from './customer-filter-dialog/customer-filter-dialog.module';
import { CustomerComponent } from './customer.component';

const routes: Routes = [
  {
    path: '',
    component: CustomerComponent,
    outlet: 'dashboard'
  }
]


@NgModule({
  declarations: [CustomerComponent],
  imports: [
    CommonModule, IonicModule, FormsModule,
    RouterModule.forChild(routes),

  ],
  entryComponents: [CustomerFilterDialogModule],
  exports: [
    CustomerComponent
  ]
})
export class CustomerModule { }
