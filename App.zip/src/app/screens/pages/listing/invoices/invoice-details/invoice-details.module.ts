import { NgModule } from '@angular/core';
import { SharedModule } from 'src/app/screens/shared/component/shared.module';
import { InvoiceDetailsRoutingModule } from './invoice-details-routing.module';
import { InvoiceDetailsComponent } from './invoice-details.component';


@NgModule({
  declarations: [InvoiceDetailsComponent],
  imports: [SharedModule, InvoiceDetailsRoutingModule],
  exports: [InvoiceDetailsComponent, InvoiceDetailsRoutingModule],
})
export class InvoiceDetailsModule { }
