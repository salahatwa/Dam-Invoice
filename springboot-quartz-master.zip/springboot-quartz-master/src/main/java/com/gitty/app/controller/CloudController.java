package com.gitty.app.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.gitty.app.common.CloudContent;
import com.gitty.app.common.CloudUser;
import com.gitty.app.service.CloudService;

import io.swagger.v3.oas.annotations.parameters.RequestBody;

@RestController
@RequestMapping("/api/cloud")
public class CloudController {

	private String token = "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";
	public static final String API_VERSION_SPEC = "application/vnd.github.v3+json";

	@Autowired
	private CloudService cloudService;

	@GetMapping("/userdtls")
	public CloudUser getUserDetails() throws Exception {
		return cloudService.getUserDetails(token);
	}

	
	@GetMapping("/createRepo")
	public boolean createRepo(@RequestParam(name = "name") String name,@RequestParam(name = "desc") String desc) throws Exception {
		return cloudService.createRepo(token, name, desc);
	}

	
	@DeleteMapping("/deleteRepo")
	public boolean deleteRepo(@RequestParam(name = "name") String name,@RequestParam(name = "owner") String owner) throws Exception {
		return cloudService.deleteRepo(token, owner, name);
	}
	
	
	@PostMapping("/saveCollection")
	public CloudContent saveCollection(@RequestParam(name = "loginName") String loginName,@RequestBody CloudContent content) throws Exception {
		return cloudService.save(token,loginName, content);
	}
}
