package com.gitty.app.controller;

import java.util.List;

import retrofit2.Call;
import retrofit2.http.Body;
import retrofit2.http.DELETE;
import retrofit2.http.GET;
import retrofit2.http.Header;
import retrofit2.http.POST;
import retrofit2.http.Path;

public interface RepositoryInterface {

	   @GET("user/repos")
	    Call<List<Object>> listRepos(@Header("Authorization") String accessToken,
	                                           @Header("Accept") String apiVersionSpec);

	    @DELETE("repos/{owner}/{repo}")
	    Call<Object> deleteRepo(@Header("Authorization") String accessToken, @Header("Accept") String apiVersionSpec,
	                            @Path("repo") String repo, @Path("owner") String owner);

	    @POST("user/repos")
	    Call<Object> createRepo(@Body Object repo, @Header("Authorization") String accessToken,
	                                      @Header("Accept") String apiVersionSpec,
	                                      @Header("Content-Type") String contentType);
}
