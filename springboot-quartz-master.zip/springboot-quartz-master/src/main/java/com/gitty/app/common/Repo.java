package com.gitty.app.common;

import lombok.Data;

@Data
public class Repo {
	private String full_name;
	private String status;
	private String html_url;
}
