package com.gitty.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CloudApplication {

	public static void main(String[] args) {
		SpringApplication.run(CloudApplication.class, args);
//		System.setProperty("https.protocols", "TLSv1,TLSv1.1,TLSv1.2");
//		System.setProperty("http.proxyHost", "proxy.alinma.internal");
//		System.setProperty("http.proxyPort", "8080");
	}
}
