package com.gitty.app.service;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpMethod;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.gitty.app.common.CloudContent;
import com.gitty.app.common.CloudUser;
import com.gitty.app.common.Repo;
import com.gitty.app.service.core.RestCore;
import com.gitty.app.service.core.RestCoreModel;

@Service
public class GitHubCloudServiceImpl implements CloudService {

	@Autowired
	private RestCore restCore;

	private ObjectMapper mapper = new ObjectMapper();

	@Override
	public CloudUser getUserDetails(String token) {
		RestCoreModel model = new RestCoreModel();
		model.setUrl("https://api.github.com/user");
		model.getHeaders().add("Accept", "application/vnd.github.v3+json");
		model.getHeaders().add("Authorization", "Bearer " + token);
		model.setMethod(HttpMethod.GET);
		CloudUser user = restCore.call(model, CloudUser.class);

		return user;
	}

	@Override
	public boolean createRepo(String token, String repo, String desc) {
		try {
			RestCoreModel model = new RestCoreModel();
			model.setUrl("https://api.github.com/user/repos");
			model.getHeaders().add("Accept", "application/vnd.github.v3+json");
			model.getHeaders().add("Authorization", "Bearer " + token);
			model.setMethod(HttpMethod.POST);

			Map<String, String> repoM = new HashMap<>();
			repoM.put("name", repo);
			repoM.put("description", desc);
			model.setBody(repoM);
			restCore.call(model, Repo.class);

			return false;
		} catch (Exception ex) {
			System.err.println("Repository already exist" + ex.getMessage());
			return true;
		}
	}

	@Override
	public boolean deleteRepo(String token, String owner, String repo) {
		RestCoreModel model = new RestCoreModel();
		model.setUrl("https://api.github.com/repos/" + owner + "/" + repo);
		model.getHeaders().add("Accept", "application/vnd.github.v3+json");
		model.getHeaders().add("Authorization", "Bearer " + token);
		model.setMethod(HttpMethod.DELETE);

		String result = restCore.call(model, String.class);
		System.out.println(result);
		return true;
	}

	@Override
	public List<Repo> getRepos(String token) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public CloudContent save(String token, String loginName, CloudContent content) {
		RestCoreModel model = new RestCoreModel();

		model.setUrl("https://api.github.com/repos/" + loginName + "/" + content.getRepo() + "/contents/"
				+ content.getPath());
		model.getHeaders().add("Accept", "application/vnd.github.v3+json");
		model.getHeaders().add("Authorization", "Bearer " + token);
		model.setMethod(HttpMethod.PUT);

		Map<String, String> io = new HashMap<>();
		io.put("message", "Upload pictures via Zattona(https://github.com/XPoet/picx)");
		io.put("branch", content.getBranch());
		io.put("content", content.getBase64Content());
		io.put("sha", content.getSha());
		model.setBody(io);
		String rs = restCore.call(model, String.class);
		System.out.println(rs);
		return content;
	}

	public boolean isValid(String json) {
		try {
			new JSONObject(json);
			return true;

		} catch (Exception ex) {
			System.out.println(ex.getMessage());
			return false;
		}
	}

	public CloudContent update(String token, String loginName, CloudContent content) throws Exception {

		CloudContent existContent = find(token, loginName, content);

		String decoded = new String(Base64.getDecoder().decode(existContent.getBase64Content()),
				StandardCharsets.UTF_8);

		if (isValid(decoded) && isValid(content.getBase64Content())) {
			List<Object> collection = mapper.readValue(decoded, new TypeReference<List<Object>>() {
			});

			List<Object> entryColection = mapper.readValue(content.getBase64Content(),
					new TypeReference<List<Object>>() {
					});

			if (Objects.nonNull(collection) && !collection.isEmpty()) {

				if (entryColection.size() == 1) {
					collection.add(collection.get(0));
				}

				for (int i = entryColection.size() - 1; i >= 0; i--) {
//		          let d = data[i];
//		          d._id = UUID().replace(/-/g, '');
					collection.add(entryColection.get(0));
				}
			} 
			else {
				collection = new ArrayList<>(entryColection);
			}

			content.setBase64Content(mapper.writeValueAsString(collection));
			content = save(token, loginName, content);

		}

		return content;
	}

	@Override
	public CloudContent find(String token, String loginName, CloudContent content) {
		RestCoreModel model = new RestCoreModel();

		model.setUrl("https://api.github.com/repos/" + loginName + "/" + content.getRepo() + "/contents/"
				+ content.getPath());
		model.getHeaders().add("Accept", "application/vnd.github.v3+json");
		model.getHeaders().add("Authorization", "Bearer " + token);
		model.setMethod(HttpMethod.GET);

		String rs = restCore.call(model, String.class);

		System.out.println(rs);

		content = restCore.call(model, CloudContent.class);

		return content;

	}

}
