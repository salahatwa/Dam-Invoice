package com.gitty.app.service;

import java.util.List;

import com.gitty.app.common.CloudContent;
import com.gitty.app.common.CloudUser;
import com.gitty.app.common.Repo;

public interface CloudService {

	public CloudUser getUserDetails(String token);

	public boolean createRepo(String token, String repo, String desc);

	public boolean deleteRepo(String token, String owner, String repo);

	public List<Repo> getRepos(String token);

	public CloudContent save(String token,String loginName, CloudContent content);

	public CloudContent find(String token, String loginName, CloudContent content);
}
