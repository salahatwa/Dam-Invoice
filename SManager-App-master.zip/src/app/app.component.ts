import { Component } from '@angular/core';
import { Router } from '@angular/router';
import { SplashScreen } from '@capacitor/splash-screen';
import { MenuController } from '@ionic/angular';
import { ConfigService } from './services/config.service';
import { UserService } from './services/user.service';

@Component({
  selector: 'app-root',
  templateUrl: 'app.component.html',
  styleUrls: ['app.component.scss'],
})
export class AppComponent {
  constructor(
    private user: UserService,
    private router: Router,
    private menu: MenuController,
    private config: ConfigService) {
     this.router.navigate(['/home'], { replaceUrl: true });
  }

  ionViewDidEnter() {
    // console.log('view');
    this.config.authEvents.subscribe(user => {
      // console.log(user);
      if(user) {
        this.menu.enable(true, 'main');
      } else {
        this.menu.enable(false, 'main');
      }
    });
  }
}
