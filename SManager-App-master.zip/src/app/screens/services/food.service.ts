import { Injectable } from "@angular/core";
import { Food } from "../models/food.model";

@Injectable({
    providedIn: 'root'
})
export class FoodService {
    constructor() { }


    getFoods(): Food[] {
        return [
            {
                id: 1,
                title: 'Sea Food',
                image: 'assets/images/avatar-alt.png',
                price: 12,
                description: 'small desction '
            },
            {
                id: 2,
                title: 'Rise',
                image: 'assets/images/avatar-alt.png',
                price: 12,
                description: 'small 2 desction '
            },
            {
                id: 3,
                title: 'Orange',
                image: 'assets/images/avatar-alt.png',
                price: 12,
                description: 'small 3 desction '
            }
        ];
    }


    getFood(id: number): Food {
        return this.getFoods().find((food) => food.id == id);
    }
}