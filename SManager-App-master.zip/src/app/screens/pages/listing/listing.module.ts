import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';

import { IonicModule } from '@ionic/angular';

import { ListingPageRoutingModule } from './listing-routing.module';

import { ListingPage } from './listing.page';
import { SearchbarModule } from '../../component/searchbar/searchbar.module';
import { CategoryItemModule } from '../../component/category-item/category-item.module';
import { FoodCardModule } from '../../component/food-card/food-card.module';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    IonicModule,
    ListingPageRoutingModule,
    SearchbarModule,
    CategoryItemModule,
    FoodCardModule
  ],
  declarations: [ListingPage]
})
export class ListingPageModule {}
