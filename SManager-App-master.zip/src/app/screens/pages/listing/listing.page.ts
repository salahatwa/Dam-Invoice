import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Category } from '../../models/category.model';
import { Food } from '../../models/food.model';
import { FoodService } from '../../services/food.service';

@Component({
  selector: 'app-listing',
  templateUrl: './listing.page.html',
  styleUrls: ['./listing.page.scss'],
})
export class ListingPage implements OnInit {
  categories: Category[] = [];
  foods: Food[] = [];

  constructor(private foodService: FoodService, private router: Router) { }

  ngOnInit() {
    this.getCategories();
    this.foods = this.foodService.getFoods();
  }

  goToDetailPage(id: number) {
    console.log(id);
    this.router.navigate(['detail', id]);
  }

  getCategories() {
    this.categories = [
      {
        id: 1,
        label: 'All',
        image: 'assets/images/avatar-alt.png',
        active: true
      },
      {
        id: 2,
        label: 'Cat2',
        image: 'assets/images/avatar-alt.png',
        active: false
      },
      {
        id: 3,
        label: 'Cat3',
        image: 'assets/images/avatar-alt.png',
        active: false
      },
      {
        id: 4,
        label: 'Cat4',
        image: 'assets/images/avatar-alt.png',
        active: false
      }
    ];
  }
}
