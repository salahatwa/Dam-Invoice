export interface Category {
    id: number;
    label: string;
    image: string;
    active: boolean;
}